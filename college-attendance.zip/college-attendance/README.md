# College Attendance Tracker

A personal, fully static attendance tracker: HTML5 + CSS3 + vanilla
JavaScript + `localStorage`. No backend, no build step, no database —
just files you can open locally or host on GitHub Pages.

## Pages

| File | Purpose |
|---|---|
| `index.html` | Daily Register — the main screen. Pick a date, tap Present / Absent / Holiday for each scheduled class. |
| `dashboard.html` | Overall stats, target projection, day-wise and month-wise breakdowns with charts. |
| `subjects.html` | Subject-wise attendance with per-subject history. |
| `routine.html` | Create/edit/duplicate/delete routines, manually or via PDF upload. |
| `settings.html` | Attendance target, JSON/CSV export, import, and destructive resets. |

## Running it

No build step is required.

- **Locally:** open `index.html` in a browser. (Some browsers restrict
  `fetch`/file APIs on `file://` — if the PDF import button seems inert,
  serve the folder instead: `python3 -m http.server` from this
  directory, then visit `http://localhost:8000`.)
- **GitHub Pages:** push this folder to a repository, then enable
  Pages (Settings → Pages → Deploy from branch) pointing at the
  branch/root containing these files. No server-side setup needed.

## How the data model works

Everything lives in three `localStorage` keys (see `js/storage.js`):

- `cat_routines` — an array of routines. Each routine has a name, a
  start date, an optional end date, and a list of weekly class slots
  (day, start/end time, subject, code, room, faculty).
- `cat_attendance` — attendance records keyed by date, then by class
  id: `{ "2026-09-07": { "cls_xyz": { status: "present", ... } } }`.
- `cat_settings` — target percentage, theme, last backup timestamp.

**Which routine applies to a date:** the routine whose `[startDate,
endDate]` window contains that date (see `Storage.getRoutineForDate`).
This is how creating a new routine for a future semester never
touches attendance already recorded under an older one.

**How a day's percentage is calculated:** for every class scheduled
on a date, its status is either an explicit record you saved, or —
for any date up to and including today — treated as **absent by
default** if you left it unmarked (an unticked box is an absence, as
the underlying spec asked for). Dates in the future are excluded
entirely until they happen. **Holiday** classes are excluded from
both the numerator and denominator of every percentage. See
`js/attendance.js` for the single place this logic lives.

**Target math:** `Utils.classesNeededForTarget` / `classesCanMissForTarget`
solve directly for the smallest number of classes you'd need to
attend in a row to reach your target, or the largest number you could
still miss and stay at or above it.

## PDF routine import

`js/pdf-parse.js` uses [pdf.js](https://mozilla.github.io/pdf.js/)
(loaded from cdnjs in `routine.html`) to pull text out of an uploaded
PDF, then applies simple heuristics (day-name and `HH:MM–HH:MM`
patterns) to guess rows. This is a best-effort convenience, not a
general table parser — scanned/image-only PDFs won't extract at all,
and irregular timetable layouts will need correction. Every extracted
row lands in the same editable table used for manual entry, and
nothing is saved to a routine until you press **Save routine**.

## Manual testing checklist

1. Create a routine (manually).
2. Record today's attendance.
3. Mark a class as Holiday.
4. Edit a previous day's attendance.
5. Check subject-wise percentage on `subjects.html`.
6. Check monthly percentage on `dashboard.html`.
7. Check overall percentage.
8. Create a second routine with a later start date — confirm older
   attendance is untouched.
9. Export data (Settings → Export data).
10. Import that same file back in.
11. Delete routines only, then delete everything, and confirm both
    ask for confirmation first.
12. Push to a GitHub repo, enable Pages, and open the deployed URL on
    a phone.

## Project structure

```
college-attendance/
├── index.html        Daily Register (main screen)
├── dashboard.html     Dashboard
├── subjects.html       Subject-wise analysis
├── routine.html        Routine management + PDF import
├── settings.html       Target, backup, data reset
├── css/style.css
├── js/
│   ├── storage.js      localStorage schema + CRUD
│   ├── utils.js         date helpers, percentage/target math
│   ├── attendance.js    scheduling + aggregation engine
│   ├── chart.js          dependency-free SVG bar chart
│   ├── pdf-parse.js      PDF text extraction + row heuristics
│   ├── routine.js        routine.html logic
│   ├── register.js       index.html logic
│   ├── dashboard.js      dashboard.html logic
│   ├── subjects.js       subjects.html logic
│   ├── settings.js       settings.html logic
│   └── app.js             shared shell (theme, nav, toasts)
└── README.md
```
